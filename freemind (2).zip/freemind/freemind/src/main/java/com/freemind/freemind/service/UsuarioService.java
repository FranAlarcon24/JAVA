package com.freemind.freemind.service;

public class UsuarioService {

}
