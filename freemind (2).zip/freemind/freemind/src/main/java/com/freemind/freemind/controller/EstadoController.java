package com.freemind.freemind.controller;

public class EstadoController {

}
