package com.freemind.freemind.service;

//import com.freemind.freemind.model.Actividad;
//import com.freemind.freemind.model.Usuario;
//import com.freemind.freemind.repository.ActividadRepository;
//import com.freemind.freemind.repository.UsuarioRepository;
//import com.freemind.freemind.service.ActividadService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;

//import java.util.List;

//@Service
//public class ActividadServiceImpl implements ActividadService {

    //@Autowired
    //private ActividadRepository actividadRepository;

    //@Autowired
    //private UsuarioRepository usuarioRepository;

    //@Override
    //public List<Actividad> findAll() {
        //return actividadRepository.findAll();
    //}

    //@Override
    //public Actividad save(Actividad actividad) {
        //if (actividad.getUsuarioId() != null && (actividad.getInstitucion() == null || actividad.getInstitucion().get))
    //}
//}
