package com.freemind.freemind;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreemindApplicationTests {

	@Test
	void contextLoads() {
	}

}
